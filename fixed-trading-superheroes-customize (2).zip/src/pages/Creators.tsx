import { Link } from 'react-router-dom';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export const Creators = () => {
  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'Creators', href: '/creators' }
  ];

  const creators = Array.from({ length: 100 }, (_, i) => {
    const names = ['Stan Lee', 'Jack Kirby', 'Frank Miller', 'Alan Moore', 'Neil Gaiman', 'Todd McFarlane', 'Steve Ditko', 'John Byrne', 'Chris Claremont', 'George Perez', 'Jim Lee', 'Rob Liefeld', 'Marc Silvestri', 'Jim Starlin', 'Marv Wolfman', 'Len Wein', 'Roy Thomas', 'Gerry Conway', 'John Romita Sr', 'Gene Colan'];
    const bios = ['Creator of legendary superheroes', 'Visionary comic book artist', 'Revolutionary storyteller', 'Master of graphic novels', 'Innovative character designer'];
    const name = names[i % names.length];
    const bio = bios[i % bios.length];
    const price = Math.random() * 1000 + 100;
    const change = (Math.random() - 0.5) * 100;
    const changePercent = (change / price) * 100;
    const sentiment = change > 10 ? 'positive' : change < -10 ? 'negative' : 'neutral';
    
    return {
      name: `${name} ${i > 19 ? `(${Math.floor(i/20) + 1})` : ''}`,
      slug: `${name.toLowerCase().replace(/\s+/g, '-')}-${i}`,
      image: `https://images.unsplash.com/photo-${1500000000000 + i}?w=100&h=100&fit=crop&crop=face`,
      price,
      change,
      changePercent,
      volume: `${(Math.random() * 5 + 0.5).toFixed(1)}M`,
      marketCap: `${(Math.random() * 20 + 5).toFixed(1)}B`,
      sentiment: sentiment as 'positive' | 'negative' | 'neutral',
      bio
    };
  });

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'negative': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <Minus className="w-4 h-4 text-yellow-400" />;
    }
  };

  const getSentimentColor = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return 'text-green-400';
      case 'negative': return 'text-red-400';
      default: return 'text-yellow-400';
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="container mx-auto px-6 py-8">
        <Breadcrumbs items={breadcrumbItems} />
        <div className="mt-6">
          <h1 className="text-3xl font-bold mb-8">Comic Book Creators</h1>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {creators.map((creator, index) => (
              <Link key={index} to={`/creators/${creator.slug}`}>
                <Card className="bg-slate-800/50 border-slate-700 hover:bg-slate-800/70 transition-all duration-300 cursor-pointer group">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <img 
                          src={creator.image} 
                          alt={creator.name}
                          className="w-12 h-12 rounded-full bg-slate-700"
                        />
                        <div>
                          <h3 className="font-bold text-lg group-hover:text-blue-400 transition-colors">
                            {creator.name}
                          </h3>
                          <p className="text-sm text-slate-400">{creator.bio}</p>
                        </div>
                      </div>
                      {getSentimentIcon(creator.sentiment)}
                    </div>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-2xl font-bold">${creator.price.toFixed(2)}</span>
                        <div className="flex items-center space-x-2">
                          <span className={`text-sm font-medium ${
                            creator.change >= 0 ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {creator.change >= 0 ? '+' : ''}${creator.change.toFixed(2)}
                          </span>
                          <Badge 
                            variant="secondary" 
                            className={`${
                              creator.change >= 0 ? 'bg-green-900/30 text-green-400' : 'bg-red-900/30 text-red-400'
                            }`}
                          >
                            {creator.change >= 0 ? '+' : ''}{creator.changePercent.toFixed(2)}%
                          </Badge>
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-slate-400">Volume:</span>
                          <div className="font-medium">{creator.volume}</div>
                        </div>
                        <div>
                          <span className="text-slate-400">Market Cap:</span>
                          <div className="font-medium">{creator.marketCap}</div>
                        </div>
                      </div>
                      
                      <div className="pt-2 border-t border-slate-700">
                        <div className="flex items-center justify-between">
                          <span className="text-sm text-slate-400">Sentiment:</span>
                          <Badge 
                            variant="outline" 
                            className={`${getSentimentColor(creator.sentiment)} border-current`}
                          >
                            {creator.sentiment.charAt(0).toUpperCase() + creator.sentiment.slice(1)}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};