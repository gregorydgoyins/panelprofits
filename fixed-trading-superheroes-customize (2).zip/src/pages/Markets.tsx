import { MarketDashboard } from '@/components/MarketDashboard';
import { Breadcrumbs } from '@/components/Breadcrumbs';

export const Markets = () => {
  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'Markets', href: '/markets' }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="container mx-auto px-6 py-8">
        <Breadcrumbs items={breadcrumbItems} />
        <div className="mt-6">
          <h1 className="text-3xl font-bold mb-8">Markets</h1>
          <MarketDashboard />
        </div>
      </div>
    </div>
  );
};