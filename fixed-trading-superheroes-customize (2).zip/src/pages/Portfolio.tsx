import { HeroProfile } from '@/components/HeroProfile';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const Portfolio = () => {
  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'Portfolio', href: '/portfolio' }
  ];

  const portfolioHeroes = [
    {
      name: 'Spider-Man',
      shares: 150,
      currentPrice: 245.67,
      totalValue: 36850.50,
      change: 12.45,
      changePercent: 5.34
    },
    {
      name: 'Batman',
      shares: 75,
      currentPrice: 412.89,
      totalValue: 30966.75,
      change: -8.23,
      changePercent: -1.95
    }
  ];

  const totalPortfolioValue = portfolioHeroes.reduce((sum, hero) => sum + hero.totalValue, 0);

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="container mx-auto px-6 py-8">
        <Breadcrumbs items={breadcrumbItems} />
        <div className="mt-6">
          <h1 className="text-3xl font-bold mb-8">Portfolio</h1>
          
          <Card className="bg-slate-900 border-slate-700 mb-8">
            <CardHeader>
              <CardTitle className="text-white">Portfolio Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400">
                ${totalPortfolioValue.toLocaleString()}
              </div>
              <p className="text-gray-400">Total Portfolio Value</p>
            </CardContent>
          </Card>

          <div className="grid gap-6">
            {portfolioHeroes.map((hero, index) => (
              <Card key={index} className="bg-slate-900 border-slate-700">
                <CardContent className="p-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-xl font-bold text-white">{hero.name}</h3>
                      <p className="text-gray-400">{hero.shares} shares</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-white">
                        ${hero.totalValue.toLocaleString()}
                      </div>
                      <Badge className={hero.change >= 0 ? 'bg-green-600' : 'bg-red-600'}>
                        {hero.change >= 0 ? '+' : ''}${hero.change} ({hero.changePercent}%)
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};