import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Calendar, User, ExternalLink } from 'lucide-react';
import { TradingChart } from '@/components/TradingChart';

const NewsDetail: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  
  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'News', href: '/news' },
    { label: 'Story Details', isActive: true }
  ];

  // Enhanced story details with more robust content
  const getStoryDetails = (slug: string) => {
    const stories: { [key: string]: any } = {
      'spider-man': {
        headline: "Spider-Man Industries Swings to New Heights After Breakthrough Innovation",
        price: "$45.67",
        priceChange: "+$3.24 (7.6%)",
        sentiment: "positive",
        publishedAt: "December 15, 2024 - 2:30 PM EST",
        author: "Sarah Chen, Financial Reporter",
        source: "Comic Stock Exchange Daily",
        summary: "Spider-Man Industries announces revolutionary web-technology breakthrough that could transform urban transportation, sending shares soaring in after-hours trading.",
        content: `NEW YORK - Spider-Man Industries (NYSE: SPDR) surged 7.6% in after-hours trading following the company's announcement of a groundbreaking advancement in their proprietary web-technology platform. The innovation, dubbed "Web-Transit 3.0," promises to revolutionize urban transportation through bio-engineered adhesive fibers that can support up to 10 tons while maintaining flexibility and environmental sustainability.

CEO Peter Parker stated in a press conference, "This breakthrough represents years of research and development. We're not just changing how people move through cities - we're redefining the very infrastructure of urban mobility."

The technology has already attracted interest from major metropolitan areas including New York, Los Angeles, and Tokyo, with preliminary contracts valued at over $2.8 billion. Market analysts predict this could position Spider-Man Industries as a leader in next-generation transportation solutions.

The stock's performance reflects investor confidence in the company's innovative approach to solving urban congestion problems. Trading volume increased 340% compared to the 30-day average, indicating strong institutional interest.`,
        tags: ['Technology', 'Transportation', 'Innovation', 'Urban Development'],
        creatorReference: {
          name: 'Stan Lee',
          role: 'Creator of Spider-Man',
          slug: 'stan-lee',
          keyIssues: ['Amazing Fantasy #15 (First Appearance)', 'Amazing Spider-Man #1', 'Spider-Man vs. Green Goblin Saga'],
          majorInfluences: ['Teenage superhero archetype', 'Relatable character flaws', 'Scientific responsibility themes']
        },
        relatedStocks: [
          { name: 'Stark Industries', symbol: 'STRK', price: '$89.45', change: '+2.1%' },
          { name: 'Wayne Enterprises', symbol: 'WAYN', price: '$156.78', change: '+1.8%' },
          { name: 'Oscorp', symbol: 'OSCP', price: '$34.21', change: '-0.5%' }
        ]
      }
    };
    
    const key = Object.keys(stories).find(k => slug?.includes(k)) || 'spider-man';
    return stories[key] || stories['spider-man'];
  };

  const story = getStoryDetails(slug || '');
  
  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return <TrendingUp className="w-5 h-5 text-green-400" />;
      case 'negative': return <TrendingDown className="w-5 h-5 text-red-400" />;
      default: return <Minus className="w-5 h-5 text-yellow-400" />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Breadcrumbs items={breadcrumbItems} />
      
      <div className="container mx-auto px-6 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card className="bg-white border border-gray-200 shadow-lg">
              <CardHeader className="border-b border-gray-200 bg-gray-50">
                <div className="text-center mb-4">
                  <h1 className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-2">COMIC STOCK EXCHANGE DAILY</h1>
                  <div className="w-full h-px bg-gray-300 mb-4"></div>
                </div>
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    {getSentimentIcon(story.sentiment)}
                    <Badge className={story.sentiment === 'positive' ? 'bg-green-600' : 'bg-red-600'}>
                      {story.sentiment === 'positive' ? 'Bullish' : 'Bearish'}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-green-600">{story.price}</div>
                    <div className="text-sm text-green-600">{story.priceChange}</div>
                  </div>
                </div>
                <CardTitle className="text-3xl text-black mb-4 font-serif leading-tight">{story.headline}</CardTitle>
                <div className="flex items-center space-x-4 text-gray-600 text-sm border-t pt-4">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{story.publishedAt}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <User className="w-4 h-4" />
                    <span>{story.author}</span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-8">
                <p className="text-lg text-gray-700 mb-6 font-medium leading-relaxed border-l-4 border-blue-500 pl-4 italic">{story.summary}</p>
                <div className="prose prose-lg max-w-none">
                  {story.content.split('\n\n').map((paragraph: string, index: number) => (
                    <p key={index} className="text-gray-800 mb-4 leading-relaxed font-serif text-base">
                      {paragraph}
                    </p>
                  ))}
                </div>
                
                {/* Enhanced Creator Reference Section */}
                <div className="mt-8 p-6 bg-blue-50 border border-blue-200 rounded-lg">
                  <h3 className="text-lg font-bold text-gray-800 mb-4">Character Creator Reference</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <p className="text-gray-700 font-medium text-lg">{story.creatorReference.name}</p>
                          <p className="text-gray-600 text-sm">{story.creatorReference.role}</p>
                        </div>
                        <Link 
                          to={`/creators/${story.creatorReference.slug}`}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                        >
                          View Bio Page →
                        </Link>
                      </div>
                      
                      <div className="mb-4">
                        <h4 className="font-semibold text-gray-800 mb-2">Key Issues & First Appearances:</h4>
                        <ul className="text-sm text-gray-600 space-y-1">
                          {story.creatorReference.keyIssues.map((issue: string, index: number) => (
                            <li key={index} className="flex items-center">
                              <span className="w-2 h-2 bg-blue-500 rounded-full mr-2"></span>
                              {issue}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                    
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Major Influences & Legacy:</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        {story.creatorReference.majorInfluences.map((influence: string, index: number) => (
                          <li key={index} className="flex items-center">
                            <span className="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                            {influence}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 pt-6 border-t border-gray-200">
                  <div className="flex items-center space-x-2 text-gray-500">
                    <ExternalLink className="w-4 h-4" />
                    <span className="text-sm">Source: {story.source}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
          
          {/* Enhanced Sidebar */}
          <div className="space-y-6">
            {/* Stock Chart */}
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Stock Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <TradingChart symbol="SPDR" />
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Tags</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {story.tags.map((tag: string, index: number) => (
                    <Badge key={index} variant="outline" className="border-slate-600 text-gray-400">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="text-white text-lg">Related Stocks</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {story.relatedStocks.map((stock: any, index: number) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-slate-800 rounded">
                      <div>
                        <div className="text-white font-medium">{stock.name}</div>
                        <div className="text-gray-400 text-sm">{stock.symbol}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-white font-medium">{stock.price}</div>
                        <div className={`text-sm font-bold ${
                          stock.change.startsWith('+') ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {stock.change}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
            
            <Link 
              to="/news" 
              className="block w-full bg-blue-600 hover:bg-blue-700 text-white text-center py-3 px-4 rounded-lg transition-colors"
            >
              ← Back to News
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export { NewsDetail };