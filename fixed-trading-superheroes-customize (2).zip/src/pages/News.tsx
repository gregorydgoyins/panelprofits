import { Breadcrumbs } from '@/components/Breadcrumbs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export const News = () => {
  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'News', href: '/news' }
  ];

  const newsItems = [
    {
      title: 'Spider-Man Stock Surges After New Movie Announcement',
      summary: 'Marvel announces new Spider-Man trilogy, causing stock to jump 15%',
      time: '2 hours ago',
      impact: 'positive',
      category: 'Marvel'
    },
    {
      title: 'Batman Holdings Drop on Delayed Film Release',
      summary: 'DC pushes back Batman sequel, affecting investor confidence',
      time: '4 hours ago',
      impact: 'negative',
      category: 'DC'
    },
    {
      title: 'Comic Book Market Reaches All-Time High',
      summary: 'Overall superhero stock market hits record $2.5 trillion valuation',
      time: '6 hours ago',
      impact: 'positive',
      category: 'Market'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="container mx-auto px-6 py-8">
        <Breadcrumbs items={breadcrumbItems} />
        <div className="mt-6">
          <h1 className="text-3xl font-bold mb-8">News</h1>
          
          <div className="space-y-6">
            {newsItems.map((item, index) => (
              <Card key={index} className="bg-slate-900 border-slate-700 hover:border-slate-600 transition-colors cursor-pointer">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-white text-lg">{item.title}</CardTitle>
                    <div className="flex space-x-2">
                      <Badge className={item.impact === 'positive' ? 'bg-green-600' : 'bg-red-600'}>
                        {item.impact === 'positive' ? 'Bullish' : 'Bearish'}
                      </Badge>
                      <Badge variant="outline" className="border-slate-600 text-gray-400">
                        {item.category}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-300 mb-2">{item.summary}</p>
                  <p className="text-gray-500 text-sm">{item.time}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};