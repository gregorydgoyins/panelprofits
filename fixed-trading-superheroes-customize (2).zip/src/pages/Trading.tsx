import { Breadcrumbs } from '@/components/Breadcrumbs';
import { TradingChart } from '@/components/TradingChart';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useState } from 'react';

export const Trading = () => {
  const [orderType, setOrderType] = useState('buy');
  const [shares, setShares] = useState('');
  const [price, setPrice] = useState('');

  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'Trading', href: '/trading' }
  ];

  const handleTrade = () => {
    console.log(`${orderType} ${shares} shares at $${price}`);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <div className="container mx-auto px-6 py-8">
        <Breadcrumbs items={breadcrumbItems} />
        <div className="mt-6">
          <h1 className="text-3xl font-bold mb-8">Trading</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Price Chart</CardTitle>
                </CardHeader>
                <CardContent>
                  <TradingChart />
                </CardContent>
              </Card>
            </div>
            
            <div>
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader>
                  <CardTitle className="text-white">Place Order</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex space-x-2">
                    <Button
                      onClick={() => setOrderType('buy')}
                      className={orderType === 'buy' ? 'bg-green-600' : 'bg-slate-700'}
                    >
                      Buy
                    </Button>
                    <Button
                      onClick={() => setOrderType('sell')}
                      className={orderType === 'sell' ? 'bg-red-600' : 'bg-slate-700'}
                    >
                      Sell
                    </Button>
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Shares</label>
                    <Input
                      type="number"
                      value={shares}
                      onChange={(e) => setShares(e.target.value)}
                      className="bg-slate-800 border-slate-600 text-white"
                      placeholder="Enter shares"
                    />
                  </div>
                  
                  <div>
                    <label className="block text-sm text-gray-400 mb-2">Price</label>
                    <Input
                      type="number"
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="bg-slate-800 border-slate-600 text-white"
                      placeholder="Enter price"
                    />
                  </div>
                  
                  <Button
                    onClick={handleTrade}
                    className={`w-full ${orderType === 'buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'}`}
                  >
                    {orderType === 'buy' ? 'Buy' : 'Sell'} Order
                  </Button>
                  
                  <div className="pt-4 border-t border-slate-700">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Current Price:</span>
                      <Badge className="bg-blue-600">$245.67</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};