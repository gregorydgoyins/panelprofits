import React from 'react';
import { MarketGrid } from '@/components/MarketGrid';
import { MarketDashboard } from '@/components/MarketDashboard';
import { HeroProfile } from '@/components/HeroProfile';
import { SuperHeroSection } from '@/components/SuperHeroSection';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, Grid3X3, User } from 'lucide-react';

const Index: React.FC = () => {
  const heroData = {
    name: 'Todd McFarlane',
    title: 'Artist/Writer/Publisher/Entrepreneur',
    symbol: 'STMFS',
    image: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=800&h=600&fit=crop',
    price: 2500,
    marketCap: 'CC 125.0M',
    volume: 'CC 850.0K',
    change: 5.2,
    about: 'Todd McFarlane is a Canadian comic book creator, artist, writer, and entrepreneur who has revolutionized the comic book industry through his groundbreaking work and business ventures.'
  };

  return (
    <div className="min-h-screen bg-slate-950">
      {/* Dynamic Superhero Section */}
      <SuperHeroSection />
      
      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="market" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800 mb-8">
            <TabsTrigger value="market" className="flex items-center space-x-2 font-primary">
              <Grid3X3 className="w-4 h-4" />
              <span>Market Overview</span>
            </TabsTrigger>
            <TabsTrigger value="dashboard" className="flex items-center space-x-2 font-primary">
              <BarChart3 className="w-4 h-4" />
              <span>Trading Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center space-x-2 font-primary">
              <User className="w-4 h-4" />
              <span>Hero Profile</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="market">
            <MarketGrid />
          </TabsContent>
          
          <TabsContent value="dashboard">
            <MarketDashboard />
          </TabsContent>
          
          <TabsContent value="profile">
            <HeroProfile {...heroData} />
          </TabsContent>
        </Tabs>
      </main>
    </div>
  );
};

export { Index };