import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { ThemeProvider } from '@/components/theme-provider';
import { AppLayout } from '@/components/AppLayout';
import { Index } from '@/pages/Index';
import { Markets } from '@/pages/Markets';
import { Portfolio } from '@/pages/Portfolio';
import { Creators } from '@/pages/Creators';
import { Trading } from '@/pages/Trading';
import { News } from '@/pages/News';
import { NewsDetail } from '@/pages/NewsDetail';
import { CreatorProfile } from '@/components/CreatorProfile';
import { NotFound } from '@/pages/NotFound';
import './App.css';

function App() {
  return (
    <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
      <Router>
        <Routes>
          <Route path="/" element={<AppLayout />}>
            <Route index element={<Index />} />
            <Route path="markets" element={<Markets />} />
            <Route path="portfolio" element={<Portfolio />} />
            <Route path="creators" element={<Creators />} />
            <Route path="creators/:slug" element={<CreatorProfile />} />
            <Route path="trading" element={<Trading />} />
            <Route path="news" element={<News />} />
            <Route path="news/:slug" element={<NewsDetail />} />
            <Route path="*" element={<NotFound />} />
          </Route>
        </Routes>
      </Router>
    </ThemeProvider>
  );
}

export default App;