/**
 * Formats a number using toFixed safely.
 * Returns '0.00' if input is not a valid number.
 * @param {number} value - The number to format.
 * @param {number} [digits=2] - Decimal places.
 * @returns {string}
 */
export const safeToFixed = (value: number | undefined | null, digits: number = 2): string => {
  return typeof value === 'number' && !isNaN(value)
    ? value.toFixed(digits)
    : '0.00';
};