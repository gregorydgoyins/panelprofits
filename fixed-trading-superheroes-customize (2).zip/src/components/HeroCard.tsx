import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface HeroCardProps {
  name: string;
  symbol: string;
  price: number;
  change: number;
  image: string;
  marketCap: string;
  volume: string;
}

export const HeroCard = ({ name, symbol, price, change, image, marketCap, volume }: HeroCardProps) => {
  const isPositive = change > 0;
  
  return (
    <Card className="bg-slate-800 border-slate-700 hover:border-blue-500 transition-colors">
      <CardContent className="p-4">
        <div className="flex items-center space-x-3 mb-3">
          <img src={image} alt={name} className="w-10 h-10 rounded-full object-cover" />
          <div>
            <h3 className="text-white font-semibold">{name}</h3>
            <p className="text-gray-400 text-sm">{symbol}</p>
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-white text-lg font-bold">${price.toFixed(2)}</span>
            <div className={`flex items-center space-x-1 ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
              {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span className="text-sm font-medium">{Math.abs(change)}%</span>
            </div>
          </div>
          
          <div className="text-xs text-gray-400 space-y-1">
            <div className="flex justify-between">
              <span>Market Cap:</span>
              <span>{marketCap}</span>
            </div>
            <div className="flex justify-between">
              <span>Volume:</span>
              <span>{volume}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};