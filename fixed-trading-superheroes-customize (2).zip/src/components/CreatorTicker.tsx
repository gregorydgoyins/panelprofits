import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, TrendingDown, Minus, Palette, DollarSign } from 'lucide-react';

interface CreatorItem {
  id: number;
  name: string;
  work: string;
  value: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  slug: string;
}

// Generate massive amount of mock creator stories (1000+)
const generateMockCreators = (): CreatorItem[] => {
  const baseStories = [
    { name: 'Stan Lee', work: 'Amazing Spider-Man Portfolio Rises' },
    { name: 'Jack Kirby', work: 'Fantastic Four Collection Soars' },
    { name: 'Bob Kane', work: 'Batman Chronicles Value Increases' },
    { name: 'Jerry Siegel', work: 'Superman Legacy Grows' }
  ];
  
  const creators = ['Stan Lee', 'Jack Kirby', 'Bob Kane', 'Jerry Siegel', 'Joe Shuster', 'Bill Finger', 'Steve Ditko', 'Frank Miller', 'Alan Moore', 'Neil Gaiman', 'Chris Claremont', 'John Byrne', 'George Perez', 'Jim Lee', 'Todd McFarlane', 'Rob Liefeld', 'Marc Silvestri', 'Jim Starlin', 'Marv Wolfman', 'Len Wein'];
  const works = ['Amazing Spider-Man', 'Batman Chronicles', 'X-Men Legacy', 'Superman Origins', 'Wonder Woman Tales', 'Flash Adventures', 'Green Lantern Corps', 'Aquaman Depths', 'Thor Mythology', 'Captain America Shield', 'Fantastic Four', 'Avengers Assemble', 'Justice League', 'Teen Titans', 'Watchmen'];
  const actions = ['Portfolio Rises', 'Work Valued Higher', 'Legacy Grows', 'Art Appreciates', 'Collection Soars', 'Influence Expands', 'Recognition Increases', 'Market Responds', 'Fanbase Grows', 'Impact Measured'];
  
  const stories: CreatorItem[] = [];
  
  // Repeat each base story 10 times with variations
  baseStories.forEach((story, baseIndex) => {
    for (let i = 0; i < 10; i++) {
      stories.push({
        id: baseIndex * 10 + i + 1,
        name: story.name,
        work: `${story.work} - Update ${i + 1}`,
        value: `$${(Math.random() * 500 + 50).toFixed(2)}`,
        sentiment: ['positive', 'negative', 'neutral'][Math.floor(Math.random() * 3)] as any,
        slug: `${story.name.toLowerCase().replace(/\s+/g, '-')}-${i}`
      });
    }
  });
  
  // Add 960 more generated stories for continuous loop
  for (let i = 40; i < 1000; i++) {
    const creator = creators[i % creators.length];
    const work = works[i % works.length];
    const action = actions[i % actions.length];
    
    stories.push({
      id: i + 1,
      name: creator,
      work: `${work} ${action}`,
      value: `$${(Math.random() * 500 + 50).toFixed(2)}`,
      sentiment: ['positive', 'negative', 'neutral'][Math.floor(Math.random() * 3)] as any,
      slug: `${creator.toLowerCase().replace(/\s+/g, '-')}-${i}`
    });
  }
  
  return stories;
};

const CreatorTicker: React.FC = () => {
  const [creatorItems] = useState<CreatorItem[]>(generateMockCreators());

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'negative': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <Minus className="w-4 h-4 text-yellow-400" />;
    }
  };

  return (
    <div className="h-[37px] overflow-hidden relative">
      <div className="creator-ticker-container h-full">
        <div className="creator-ticker-content flex items-center h-full space-x-8 px-6">
          {creatorItems.map((creator) => (
            <div key={creator.id} className="flex items-center space-x-4 whitespace-nowrap flex-shrink-0">
              <Palette className="w-4 h-4 text-purple-400" />
              <Link 
                to={`/creators/${creator.slug}`}
                className="text-white hover:text-purple-400 transition-colors underline flex items-center space-x-2"
              >
                <span className="text-sm font-medium">{creator.name}: {creator.work}</span>
              </Link>
              <div className="flex items-center space-x-2">
                <DollarSign className="w-4 h-4 text-green-400" />
                <span className="text-green-400 text-sm font-bold">{creator.value}</span>
                {getSentimentIcon(creator.sentiment)}
              </div>
              <span className="text-slate-500 mx-4">•</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export { CreatorTicker };