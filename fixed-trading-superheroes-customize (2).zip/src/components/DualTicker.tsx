import React, { useState, useEffect, lazy, Suspense } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, TrendingDown, Minus, Newspaper, DollarSign, Palette } from 'lucide-react';

interface NewsItem {
  id: number;
  headline: string;
  price: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  slug: string;
}

interface CreatorItem {
  id: number;
  name: string;
  work: string;
  value: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  slug: string;
}

// Lazy load ticker components
const NewsTicker = lazy(() => import('./NewsTicker').then(module => ({ default: module.NewsTicker })));
const CreatorTicker = lazy(() => import('./CreatorTicker').then(module => ({ default: module.CreatorTicker })));

const DualTicker: React.FC = () => {
  return (
    <div className="bg-slate-800/90 border-b border-slate-700">
      {/* News Ticker - Top Line */}
      <Suspense fallback={<div className="h-[37px] bg-slate-800 animate-pulse" />}>
        <NewsTicker />
      </Suspense>

      {/* 2px Separator */}
      <div className="h-[2px] bg-slate-700"></div>

      {/* Creators Ticker - Bottom Line */}
      <Suspense fallback={<div className="h-[37px] bg-slate-800 animate-pulse" />}>
        <CreatorTicker />
      </Suspense>
    </div>
  );
};

export { DualTicker };