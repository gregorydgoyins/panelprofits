import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowUpRight, ArrowDownRight, Activity, DollarSign } from 'lucide-react';

const topMovers = [
  { name: 'Spider-Man', symbol: 'SPDR', change: 5.2, volume: 'CC 850K' },
  { name: 'Wonder Woman', symbol: 'WNDR', change: 3.7, volume: 'CC 920K' },
  { name: 'Batman', symbol: 'BTMN', change: 1.8, volume: 'CC 1.5M' },
  { name: 'Iron Man', symbol: 'IRON', change: -2.1, volume: 'CC 1.2M' }
];

export const MarketDashboard = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-r from-green-900 to-green-800 border-green-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-200 text-sm">Market Cap</p>
                <p className="text-white text-3xl font-bold">CC 2.1B</p>
                <p className="text-green-300 text-sm flex items-center">
                  <ArrowUpRight className="w-4 h-4 mr-1" />
                  +12.5% today
                </p>
              </div>
              <DollarSign className="text-green-300 w-12 h-12" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-blue-900 to-blue-800 border-blue-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-200 text-sm">24h Volume</p>
                <p className="text-white text-3xl font-bold">CC 45.2M</p>
                <p className="text-blue-300 text-sm flex items-center">
                  <Activity className="w-4 h-4 mr-1" />
                  High activity
                </p>
              </div>
              <Activity className="text-blue-300 w-12 h-12" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-purple-900 to-purple-800 border-purple-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-200 text-sm">Active Heroes</p>
                <p className="text-white text-3xl font-bold">847</p>
                <p className="text-purple-300 text-sm">Tradeable assets</p>
              </div>
              <div className="text-purple-300 text-4xl font-bold">#</div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center space-x-2">
            <Activity className="w-5 h-5" />
            <span>Top Movers</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topMovers.map((mover, index) => {
              const isPositive = mover.change >= 0;
              return (
                <div key={index} className="flex items-center justify-between p-4 bg-slate-700 rounded-lg hover:bg-slate-600 transition-colors cursor-pointer">
                  <div className="flex items-center space-x-4">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${isPositive ? 'bg-green-600' : 'bg-red-600'}`}>
                      {isPositive ? (
                        <ArrowUpRight className="w-5 h-5 text-white" />
                      ) : (
                        <ArrowDownRight className="w-5 h-5 text-white" />
                      )}
                    </div>
                    <div>
                      <p className="text-white font-semibold">{mover.name}</p>
                      <p className="text-gray-400 text-sm">{mover.symbol}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className={`${isPositive ? 'bg-green-600' : 'bg-red-600'} mb-1`}>
                      {isPositive ? '+' : ''}{mover.change.toFixed(1)}%
                    </Badge>
                    <p className="text-gray-400 text-sm">{mover.volume}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};