import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, TrendingDown, Minus, Newspaper, DollarSign } from 'lucide-react';

interface NewsItem {
  id: number;
  headline: string;
  price: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  slug: string;
}

// Generate massive amount of mock news stories (1000+)
const generateMockNews = (): NewsItem[] => {
  const baseStories = [
    'Spider-Man Stock Soars After New Movie Deal',
    'Batman Enterprises Reports Record Quarterly Earnings',
    'Iron Man Tech Division Announces Revolutionary Breakthrough',
    'Wonder Woman Comics See 300% Increase in Trading Volume'
  ];
  
  const heroes = ['Spider-Man', 'Batman', 'Iron Man', 'Wonder Woman', 'Superman', 'Flash', 'Green Lantern', 'Aquaman', 'Thor', 'Captain America', 'Hulk', 'Black Widow', 'Hawkeye', 'Ant-Man', 'Wasp', 'Doctor Strange', 'Scarlet Witch', 'Vision', 'Falcon', 'Winter Soldier'];
  const actions = ['Soars', 'Plummets', 'Stabilizes', 'Surges', 'Dips', 'Rallies', 'Climbs', 'Falls', 'Rebounds', 'Slides', 'Jumps', 'Crashes', 'Recovers', 'Spikes', 'Drops'];
  const contexts = ['After Earnings', 'On Market News', 'Following Merger', 'Due to Innovation', 'Amid Speculation', 'Post-Launch', 'During Trading', 'On Announcement', 'After Review', 'Following Update', 'Breaking News', 'Market Close', 'Pre-Market', 'Analyst Upgrade', 'Sector Rotation'];
  
  const stories: NewsItem[] = [];
  
  // Repeat each base story 10 times with variations
  baseStories.forEach((story, baseIndex) => {
    for (let i = 0; i < 10; i++) {
      stories.push({
        id: baseIndex * 10 + i + 1,
        headline: `${story} - Update ${i + 1}`,
        price: `$${(Math.random() * 100 + 10).toFixed(2)}`,
        sentiment: ['positive', 'negative', 'neutral'][Math.floor(Math.random() * 3)] as any,
        slug: `story-${baseIndex}-${i}`
      });
    }
  });
  
  // Add 960 more generated stories for continuous loop
  for (let i = 40; i < 1000; i++) {
    const hero = heroes[i % heroes.length];
    const action = actions[i % actions.length];
    const context = contexts[i % contexts.length];
    
    stories.push({
      id: i + 1,
      headline: `${hero} ${action} ${context}`,
      price: `$${(Math.random() * 100 + 10).toFixed(2)}`,
      sentiment: ['positive', 'negative', 'neutral'][Math.floor(Math.random() * 3)] as any,
      slug: `${hero.toLowerCase().replace(/\s+/g, '-')}-${i}`
    });
  }
  
  return stories;
};

const NewsTicker: React.FC = () => {
  const [newsItems] = useState<NewsItem[]>(generateMockNews());

  const getSentimentIcon = (sentiment: string) => {
    switch (sentiment) {
      case 'positive': return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'negative': return <TrendingDown className="w-4 h-4 text-red-400" />;
      default: return <Minus className="w-4 h-4 text-yellow-400" />;
    }
  };

  return (
    <div className="h-[37px] overflow-hidden relative border-b border-slate-600">
      <div className="news-ticker-container h-full">
        <div className="news-ticker-content flex items-center h-full space-x-8 px-4">
          {newsItems.map((story) => (
            <div key={story.id} className="flex items-center space-x-4 whitespace-nowrap flex-shrink-0">
              <Newspaper className="w-4 h-4 text-blue-400" />
              <Link 
                to={`/news/${story.slug}`}
                className="text-white hover:text-blue-400 transition-colors underline flex items-center space-x-2"
              >
                <span className="text-sm font-medium">{story.headline}</span>
              </Link>
              <div className="flex items-center space-x-2">
                <DollarSign className="w-4 h-4 text-green-400" />
                <span className="text-green-400 text-sm font-bold">{story.price}</span>
                {getSentimentIcon(story.sentiment)}
              </div>
              <span className="text-slate-500 mx-4">•</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export { NewsTicker };