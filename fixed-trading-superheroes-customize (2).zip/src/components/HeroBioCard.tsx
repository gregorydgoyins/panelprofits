import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { TrendingUp, TrendingDown, DollarSign, Users, Shield, Zap } from 'lucide-react';
import { Breadcrumbs } from './Breadcrumbs';

interface HeroBioCardProps {
  hero: {
    id: number;
    name: string;
    power: string;
    icon: any;
    gradient: string;
    image: string;
    origin?: string;
    sidekick?: string;
    history?: string;
    stockPrice?: number;
    fundPrice?: number;
    bondPrice?: number;
    marketCap?: string;
    volume?: string;
    change?: number;
  };
  onClose: () => void;
}

const HeroBioCard: React.FC<HeroBioCardProps> = ({ hero, onClose }) => {
  const Icon = hero.icon;
  const isPositive = (hero.change || 0) >= 0;

  const breadcrumbItems = [
    { label: 'Heroes', href: '/' },
    { label: 'Featured Heroes', href: '/heroes' },
    { label: hero.name, isActive: true }
  ];

  const handleBreadcrumbNavigate = (href: string) => {
    if (href === '/' || href === '/heroes') {
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex flex-col z-50">
      <Breadcrumbs items={breadcrumbItems} onNavigate={handleBreadcrumbNavigate} />
      
      <div className="flex-1 overflow-y-auto p-4">
        <Card className="w-full max-w-4xl mx-auto bg-slate-900 border-slate-700">
          <CardHeader className="relative">
            <div 
              className="absolute inset-0 bg-cover bg-center opacity-20"
              style={{ backgroundImage: `url(${hero.image})` }}
            />
            <div className={`absolute inset-0 bg-gradient-to-r ${hero.gradient} opacity-10`} />
            <div className="relative flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${hero.gradient} flex items-center justify-center`}>
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <div>
                  <CardTitle className="text-3xl text-white">{hero.name}</CardTitle>
                  <p className="text-xl text-slate-300">{hero.power}</p>
                </div>
              </div>
              <Button onClick={onClose} variant="outline" size="sm">
                Close
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Stock Information */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-slate-800 border-slate-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Stock Price</p>
                      <p className="text-2xl font-bold text-white">${hero.stockPrice || 125.50}</p>
                    </div>
                    <DollarSign className="w-8 h-8 text-green-400" />
                  </div>
                  <div className="flex items-center mt-2">
                    {isPositive ? (
                      <TrendingUp className="w-4 h-4 text-green-400 mr-1" />
                    ) : (
                      <TrendingDown className="w-4 h-4 text-red-400 mr-1" />
                    )}
                    <span className={isPositive ? 'text-green-400' : 'text-red-400'}>
                      {isPositive ? '+' : ''}{hero.change || 2.5}%
                    </span>
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800 border-slate-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Fund Price</p>
                      <p className="text-2xl font-bold text-white">${hero.fundPrice || 89.25}</p>
                    </div>
                    <Users className="w-8 h-8 text-blue-400" />
                  </div>
                </CardContent>
              </Card>
              
              <Card className="bg-slate-800 border-slate-600">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-slate-400">Bond Price</p>
                      <p className="text-2xl font-bold text-white">${hero.bondPrice || 102.75}</p>
                    </div>
                    <Shield className="w-8 h-8 text-purple-400" />
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Hero Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-xl font-semibold text-white mb-3 flex items-center">
                  <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                  Origin Story
                </h3>
                <p className="text-slate-300 leading-relaxed">
                  {hero.origin || `${hero.name} gained their incredible powers through a mysterious accident that transformed them into one of the world's most powerful heroes. Their journey from ordinary citizen to superhero has inspired millions worldwide.`}
                </p>
              </div>
              
              <div>
                <h3 className="text-xl font-semibold text-white mb-3">Sidekick & Allies</h3>
                <p className="text-slate-300 leading-relaxed">
                  {hero.sidekick || `${hero.name} works closely with a dedicated team of allies and sidekicks who help protect the city. Together, they form an unstoppable force against evil.`}
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold text-white mb-3">Hero History</h3>
              <p className="text-slate-300 leading-relaxed">
                {hero.history || `Throughout their career, ${hero.name} has faced countless challenges and emerged victorious time and again. Their legacy continues to grow as they protect innocent lives and fight for justice across the globe.`}
              </p>
            </div>
            
            {/* Market Stats */}
            <div className="flex flex-wrap gap-4">
              <Badge variant="secondary" className="bg-slate-700 text-slate-200">
                Market Cap: {hero.marketCap || '$2.4B'}
              </Badge>
              <Badge variant="secondary" className="bg-slate-700 text-slate-200">
                Volume: {hero.volume || '1.2M'}
              </Badge>
              <Badge variant="secondary" className="bg-slate-700 text-slate-200">
                52W High: ${((hero.stockPrice || 125.50) * 1.2).toFixed(2)}
              </Badge>
              <Badge variant="secondary" className="bg-slate-700 text-slate-200">
                52W Low: ${((hero.stockPrice || 125.50) * 0.8).toFixed(2)}
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export { HeroBioCard };