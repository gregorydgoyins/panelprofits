import React from 'react';
import { Navigation } from './Navigation';
import { DualTicker } from './DualTicker';
import { Outlet } from 'react-router-dom';
import { useAppContext } from '@/contexts/AppContext';
import { useIsMobile } from '@/hooks/use-mobile';

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar } = useAppContext();
  const isMobile = useIsMobile();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      <Navigation />
      <div className="h-[76px] w-full overflow-hidden">
        <DualTicker />
      </div>
      <Outlet />
    </div>
  );
};

export { AppLayout };