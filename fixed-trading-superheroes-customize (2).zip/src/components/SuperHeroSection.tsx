import { useState, useEffect } from 'react';
import { superheroes } from '../data/superheroes';
import { HeroBioCard } from './HeroBioCard';

const SuperHeroSection = () => {
  const [currentHero, setCurrentHero] = useState(0);
  const [selectedHero, setSelectedHero] = useState<any>(null);
  
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentHero((prev) => (prev + 1) % superheroes.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const hero = superheroes[currentHero];
  const Icon = hero.icon;

  const handleHeroClick = () => {
    setSelectedHero(hero);
  };

  const handleCloseModal = () => {
    setSelectedHero(null);
  };

  // Roy Lichtenstein style pop art images
  const popArtImages = [
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=400&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1612198188060-c7c2a3b66eae?w=800&h=400&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=800&h=400&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=400&fit=crop&crop=center'
  ];

  return (
    <>
      <div 
        className="h-48 relative overflow-hidden transition-all duration-1000 border-y border-slate-700/50 cursor-pointer hover:scale-[1.02] transform"
        onClick={handleHeroClick}
      >
        {/* Pop Art Style Background */}
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000 filter contrast-125 saturate-150"
          style={{ 
            backgroundImage: `url(${popArtImages[currentHero % popArtImages.length]})`,
            filter: 'contrast(1.3) saturate(1.5) hue-rotate(15deg)'
          }}
        />
        
        {/* Comic book style overlay */}
        <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 via-blue-500/20 to-yellow-500/20 mix-blend-overlay" />
        <div className="absolute inset-0 bg-black/50" />
        
        {/* Ben-Day dots pattern overlay for Lichtenstein effect */}
        <div 
          className="absolute inset-0 opacity-30"
          style={{
            backgroundImage: 'radial-gradient(circle, rgba(255,255,255,0.3) 1px, transparent 1px)',
            backgroundSize: '8px 8px'
          }}
        />
        
        {/* Floating particles effect */}
        <div className="absolute inset-0">
          {[...Array(6)].map((_, i) => (
            <div
              key={i}
              className={`absolute w-2 h-2 bg-gradient-to-r ${hero.gradient} rounded-full animate-ping opacity-70`}
              style={{
                left: `${15 + i * 15}%`,
                top: `${25 + (i % 3) * 25}%`,
                animationDelay: `${i * 0.8}s`,
                animationDuration: '3s'
              }}
            />
          ))}
        </div>
        
        <div className="relative h-full flex items-center px-8">
          <div className="flex items-center space-x-4">
            {/* Smaller, more cohesive icon */}
            <div className={`w-14 h-14 rounded-full bg-gradient-to-r ${hero.gradient} flex items-center justify-center shadow-xl border-3 border-white/50 transform transition-all duration-1000 hover:scale-110 backdrop-blur-sm`}>
              <Icon className="w-7 h-7 text-white drop-shadow-xl" strokeWidth={2.5} />
            </div>
            
            {/* Tighter text spacing with proper cushioning */}
            <div className="space-y-1">
              <h2 className="text-3xl font-handwritten font-light text-white tracking-tight drop-shadow-2xl transform transition-all duration-1000 leading-tight">
                {hero.name}
              </h2>
              <div className="flex items-center space-x-3">
                <span className={`text-lg font-handwritten font-light bg-gradient-to-r ${hero.gradient} bg-clip-text text-transparent drop-shadow-lg tracking-tight leading-tight`}>
                  {hero.power}
                </span>
                <div className="flex space-x-1 ml-2">
                  {superheroes.slice(0, 6).map((_, index) => (
                    <div
                      key={index}
                      className={`h-1.5 rounded-full transition-all duration-500 ${
                        index === currentHero % 6
                          ? `w-6 bg-gradient-to-r ${hero.gradient} shadow-lg` 
                          : 'w-1.5 bg-white/40'
                      }`}
                    />
                  ))}
                </div>
              </div>
              <p className="text-white/60 text-xs mt-1 leading-tight">Click to view detailed bio and stock information</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* Hero Bio Modal */}
      {selectedHero && (
        <HeroBioCard hero={selectedHero} onClose={handleCloseModal} />
      )}
    </>
  );
};

export { SuperHeroSection };