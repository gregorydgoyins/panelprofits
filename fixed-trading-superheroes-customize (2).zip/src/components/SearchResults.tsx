import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { TemplateCard } from '@/components/TemplateCard';

interface Hero {
  id: number;
  name: string;
  price: number;
  change_amount: number;
  change_percent: number;
  volume: string;
  market_cap: string;
  image_url: string;
}

interface SearchResultsProps {
  query: string;
  onClose: () => void;
}

export const SearchResults = ({ query, onClose }: SearchResultsProps) => {
  const [heroes, setHeroes] = useState<Hero[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (query.trim()) {
      searchHeroes(query);
    }
  }, [query]);

  const searchHeroes = async (searchQuery: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('heroes')
        .select('*')
        .ilike('name', `%${searchQuery}%`);
      
      if (error) throw error;
      setHeroes(data || []);
    } catch (error) {
      console.error('Search error:', error);
      setHeroes([]);
    } finally {
      setLoading(false);
    }
  };

  if (!query.trim()) return null;

  return (
    <div className="absolute top-full left-0 right-0 mt-2 bg-slate-800 border border-slate-600 rounded-lg shadow-xl z-50 max-h-96 overflow-y-auto">
      <div className="p-4">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-white font-semibold">Search Results</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white">×</button>
        </div>
        
        {loading ? (
          <div className="text-gray-400 text-center py-4">Searching...</div>
        ) : heroes.length > 0 ? (
          <div className="grid gap-4">
            {heroes.map((hero) => (
              <div key={hero.id} className="scale-75 origin-top-left">
                <TemplateCard
                  name={hero.name}
                  image={hero.image_url}
                  price={hero.price}
                  change={hero.change_amount}
                  changePercent={hero.change_percent}
                  volume={hero.volume}
                  marketCap={hero.market_cap}
                />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-gray-400 text-center py-4">No heroes found</div>
        )}
      </div>
    </div>
  );
};