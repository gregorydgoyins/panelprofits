import { ChevronRight, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';

interface BreadcrumbItem {
  label: string;
  href?: string;
  isActive?: boolean;
}

interface BreadcrumbsProps {
  items: BreadcrumbItem[];
}

export const Breadcrumbs = ({ items }: BreadcrumbsProps) => {
  return (
    <nav className="bg-slate-800 border-b border-slate-700 px-6 py-3">
      <div className="flex items-center space-x-2 max-w-7xl mx-auto">
        <Link to="/">
          <Button
            variant="ghost"
            size="sm"
            className="text-gray-400 hover:text-white p-1"
          >
            <Home className="w-4 h-4" />
          </Button>
        </Link>
        
        {items.map((item, index) => (
          <div key={index} className="flex items-center space-x-2">
            <ChevronRight className="w-4 h-4 text-gray-500" />
            {item.href && !item.isActive ? (
              <Link to={item.href}>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-gray-400 hover:text-white text-sm px-2 py-1"
                >
                  {item.label}
                </Button>
              </Link>
            ) : (
              <span className={`text-sm px-2 py-1 ${
                item.isActive ? 'text-white font-medium' : 'text-gray-400'
              }`}>
                {item.label}
              </span>
            )}
          </div>
        ))}
      </div>
    </nav>
  );
};