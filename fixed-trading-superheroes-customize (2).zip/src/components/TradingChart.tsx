import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface TradingChartProps {
  symbol: string;
  price: number;
  change: number;
  data?: number[];
}

export const TradingChart = ({ symbol, price, change, data = [] }: TradingChartProps) => {
  const isPositive = change >= 0;
  
  // Generate mock chart data if none provided
  const chartData = data.length > 0 ? data : Array.from({ length: 24 }, (_, i) => {
    const basePrice = price;
    const variance = (Math.random() - 0.5) * 0.1 * basePrice;
    return basePrice + variance;
  });
  
  const maxPrice = Math.max(...chartData);
  const minPrice = Math.min(...chartData);
  const priceRange = maxPrice - minPrice;
  
  // Create SVG path for the chart line
  const pathData = chartData.map((price, index) => {
    const x = (index / (chartData.length - 1)) * 300;
    const y = 100 - ((price - minPrice) / priceRange) * 80;
    return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
  }).join(' ');
  
  return (
    <Card className="bg-slate-800 border-slate-700">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-white text-lg">{symbol}</CardTitle>
          <Badge className={`${isPositive ? 'bg-green-600' : 'bg-red-600'}`}>
            {isPositive ? '+' : ''}{change.toFixed(2)}%
          </Badge>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-white text-2xl font-bold">CC {price.toFixed(2)}</span>
          {isPositive ? (
            <TrendingUp className="text-green-400 w-5 h-5" />
          ) : (
            <TrendingDown className="text-red-400 w-5 h-5" />
          )}
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative">
          <svg width="100%" height="120" viewBox="0 0 300 100" className="overflow-visible">
            {/* Grid lines */}
            <defs>
              <pattern id="grid" width="30" height="20" patternUnits="userSpaceOnUse">
                <path d="M 30 0 L 0 0 0 20" fill="none" stroke="#374151" strokeWidth="0.5" opacity="0.3"/>
              </pattern>
            </defs>
            <rect width="300" height="100" fill="url(#grid)" />
            
            {/* Chart line */}
            <path
              d={pathData}
              fill="none"
              stroke={isPositive ? '#10b981' : '#ef4444'}
              strokeWidth="2"
              className="drop-shadow-sm"
            />
            
            {/* Area under curve */}
            <path
              d={`${pathData} L 300 100 L 0 100 Z`}
              fill={`url(#gradient-${symbol})`}
              opacity="0.1"
            />
            
            {/* Gradient definition */}
            <defs>
              <linearGradient id={`gradient-${symbol}`} x1="0%" y1="0%" x2="0%" y2="100%">
                <stop offset="0%" stopColor={isPositive ? '#10b981' : '#ef4444'} stopOpacity="0.3" />
                <stop offset="100%" stopColor={isPositive ? '#10b981' : '#ef4444'} stopOpacity="0" />
              </linearGradient>
            </defs>
            
            {/* Data points */}
            {chartData.map((price, index) => {
              const x = (index / (chartData.length - 1)) * 300;
              const y = 100 - ((price - minPrice) / priceRange) * 80;
              return (
                <circle
                  key={index}
                  cx={x}
                  cy={y}
                  r="2"
                  fill={isPositive ? '#10b981' : '#ef4444'}
                  className="opacity-0 hover:opacity-100 transition-opacity cursor-pointer"
                >
                  <title>CC {price.toFixed(2)}</title>
                </circle>
              );
            })}
          </svg>
          
          {/* Time labels */}
          <div className="flex justify-between text-xs text-gray-400 mt-2">
            <span>24h ago</span>
            <span>12h ago</span>
            <span>6h ago</span>
            <span>Now</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};