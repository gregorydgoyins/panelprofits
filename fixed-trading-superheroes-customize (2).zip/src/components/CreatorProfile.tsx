import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { ExternalLink, Play, BookOpen, Award, Calendar, TrendingUp, Newspaper } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Breadcrumbs } from '@/components/Breadcrumbs';

const CreatorProfile: React.FC = () => {
  const { slug } = useParams<{ slug: string }>();
  
  const breadcrumbItems = [
    { label: 'Home', href: '/' },
    { label: 'Creators', href: '/creators' },
    { label: 'Bio Page', isActive: true }
  ];

  // Enhanced creator data
  const creator = {
    name: 'Stan Lee',
    bio: 'Stanley Martin Lieber, known professionally as Stan Lee, was an American comic book writer, editor, publisher, and producer. He revolutionized the comic book industry by creating complex, flawed superheroes.',
    birthYear: 1922,
    deathYear: 2018,
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face',
    majorWorks: [
      { name: 'Spider-Man', year: 1962, significance: 'Revolutionary teenage superhero with relatable problems' },
      { name: 'X-Men', year: 1963, significance: 'Allegory for civil rights and social acceptance' },
      { name: 'Iron Man', year: 1963, significance: 'Technology-based hero reflecting Cold War era' },
      { name: 'Thor', year: 1962, significance: 'Blend of mythology and modern superhero genre' }
    ],
    keyIssues: [
      { title: 'Amazing Fantasy #15', year: 1962, impact: 'First appearance of Spider-Man, launched Marvel Age' },
      { title: 'Fantastic Four #1', year: 1961, impact: 'Began Marvel Universe, realistic superhero family' },
      { title: 'X-Men #1', year: 1963, impact: 'Introduced mutant concept, diversity themes' }
    ],
    majorInfluences: [
      'Teenage superhero archetype',
      'Relatable character flaws and personal problems',
      'Scientific responsibility themes',
      'Marvel Method of comic creation'
    ],
    relatedNews: [
      { title: 'Spider-Man Industries Breakthrough Innovation', slug: 'spider-man-breakthrough', date: 'Dec 15, 2024' },
      { title: 'Marvel Legacy Continues to Drive Stock Growth', slug: 'marvel-legacy-growth', date: 'Dec 10, 2024' }
    ],
    awards: ['National Medal of Arts', 'Disney Legends Award', 'Eisner Award Hall of Fame'],
    collaborations: ['Jack Kirby', 'Steve Ditko', 'John Romita Sr.']
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <Breadcrumbs items={breadcrumbItems} />
      
      <div className="container mx-auto px-6 py-8">
        <Card className="bg-slate-900 border-slate-700">
          {/* Hero Header */}
          <div className="relative bg-gradient-to-r from-blue-900 via-purple-900 to-indigo-900 p-8 rounded-t-lg">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 items-center">
              <div className="lg:col-span-1 flex justify-center">
                <img 
                  src={creator.image} 
                  alt={creator.name}
                  className="w-48 h-48 object-cover rounded-full border-4 border-white/20 shadow-2xl"
                />
              </div>
              <div className="lg:col-span-3 text-center lg:text-left">
                <h1 className="text-5xl font-bold mb-4 text-white">{creator.name}</h1>
                <p className="text-xl text-blue-200 mb-4 flex items-center justify-center lg:justify-start">
                  <Calendar className="w-5 h-5 mr-2" />
                  {creator.birthYear} - {creator.deathYear}
                </p>
                <p className="text-lg leading-relaxed text-gray-200">{creator.bio}</p>
              </div>
            </div>
          </div>

          <CardContent className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* Major Works */}
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-600">
                <h3 className="text-xl font-bold mb-4 flex items-center text-white">
                  <BookOpen className="w-5 h-5 mr-2 text-blue-400" />
                  Major Works & Creations
                </h3>
                <div className="space-y-4">
                  {creator.majorWorks.map((work, index) => (
                    <div key={index} className="p-3 bg-slate-700 rounded border-l-4 border-blue-500">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-white">{work.name}</h4>
                        <Badge variant="outline" className="text-xs">{work.year}</Badge>
                      </div>
                      <p className="text-sm text-slate-300">{work.significance}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Key Issues */}
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-600">
                <h3 className="text-xl font-bold mb-4 flex items-center text-white">
                  <Award className="w-5 h-5 mr-2 text-yellow-400" />
                  Key Issues & First Appearances
                </h3>
                <div className="space-y-4">
                  {creator.keyIssues.map((issue, index) => (
                    <div key={index} className="p-3 bg-slate-700 rounded border-l-4 border-yellow-500">
                      <div className="flex justify-between items-start mb-2">
                        <h4 className="font-bold text-white">{issue.title}</h4>
                        <Badge variant="outline" className="text-xs">{issue.year}</Badge>
                      </div>
                      <p className="text-sm text-slate-300">{issue.impact}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Major Influences */}
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-600">
                <h3 className="text-xl font-bold mb-4 flex items-center text-white">
                  <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                  Major Influences & Legacy
                </h3>
                <div className="space-y-3">
                  {creator.majorInfluences.map((influence, index) => (
                    <div key={index} className="flex items-center text-slate-300">
                      <TrendingUp className="w-4 h-4 mr-3 text-green-400 flex-shrink-0" />
                      <span className="text-sm">{influence}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Related News */}
              <div className="bg-slate-800 p-6 rounded-lg border border-slate-600">
                <h3 className="text-xl font-bold mb-4 flex items-center text-white">
                  <Newspaper className="w-5 h-5 mr-2 text-red-400" />
                  Related News & Events
                </h3>
                <div className="space-y-3">
                  {creator.relatedNews.map((news, index) => (
                    <Link key={index} to={`/news/${news.slug}`} className="block">
                      <div className="p-3 bg-slate-700 rounded hover:bg-slate-600 transition-colors border border-slate-600 hover:border-blue-500">
                        <h4 className="font-medium text-white text-sm mb-1">{news.title}</h4>
                        <p className="text-xs text-slate-400">{news.date}</p>
                      </div>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export { CreatorProfile };