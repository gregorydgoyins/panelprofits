import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Users, Briefcase, Newspaper, Search, TrendingDown } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { SearchResults } from '@/components/SearchResults';

export const Navigation = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showResults, setShowResults] = useState(false);
  const [accountBalance, setAccountBalance] = useState(2000000);
  const navigate = useNavigate();
  const location = useLocation();

  const handleNavigation = (path: string) => {
    navigate(path);
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      setShowResults(true);
    }
  };

  const menuItems = [
    { id: 'markets', label: 'Markets', icon: TrendingUp, path: '/markets' },
    { id: 'creators', label: 'Creators', icon: Users, path: '/creators' },
    { id: 'portfolio', label: 'Portfolio', icon: Briefcase, path: '/portfolio' },
    { id: 'trading', label: 'Trading', icon: TrendingDown, path: '/trading' },
    { id: 'news', label: 'News', icon: Newspaper, path: '/news' }
  ];

  return (
    <div className="bg-slate-900 border-b border-slate-700">
      {/* Top Brand Line */}
      <div className="bg-slate-950 border-b border-slate-800 px-4 py-4">
        <div className="flex items-center justify-center max-w-7xl mx-auto">
          <div className="flex items-center space-x-6 cursor-pointer px-8" onClick={() => navigate('/')}>
            <div className="w-12 h-12 bg-gradient-to-tr from-blue-500 via-purple-500 to-green-500 rounded-lg flex items-center justify-center border border-blue-300/30">
              <TrendingUp className="text-white w-7 h-7" strokeWidth={2.5} />
            </div>
            <h1 className="text-white font-secondary text-4xl font-normal tracking-wide">PANEL PROFITS</h1>
            <span className="text-gray-400 text-2xl mx-8">•</span>
            <p className="text-gray-300 text-2xl font-primary font-light">Home of the Comic Book Stock Market</p>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="px-4 py-3">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between gap-4">
            {/* Left Section - Navigation Menu */}
            <div className="flex items-center space-x-1">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = location.pathname === item.path;
                return (
                  <Button
                    key={item.id}
                    variant="ghost"
                    onClick={() => handleNavigation(item.path)}
                    className={`text-gray-300 hover:text-blue-400 flex items-center space-x-2 transition-all duration-200 px-4 py-3 mx-1 font-primary font-light text-sm ${
                      isActive 
                        ? 'text-blue-400 border-b-2 border-blue-400' 
                        : 'border-b-2 border-transparent hover:border-blue-400'
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{item.label}</span>
                  </Button>
                );
              })}
            </div>
            
            {/* Center Section - Search */}
            <div className="flex-1 flex justify-center px-4">
              <div className="relative max-w-md w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input 
                  placeholder="Search heroes, creators..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                  className="pl-10 pr-20 py-3 bg-slate-800 border-slate-600 text-white w-full font-primary"
                />
                <Button
                  onClick={handleSearch}
                  className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 px-3 bg-blue-600 hover:bg-blue-700 font-primary text-xs"
                  size="sm"
                >
                  Search
                </Button>
                {showResults && (
                  <SearchResults 
                    query={searchQuery} 
                    onClose={() => setShowResults(false)} 
                  />
                )}
              </div>
            </div>

            {/* Right Section - Portfolio Calculator */}
            <div className="flex items-center">
              <Badge className="bg-green-600 text-white font-primary font-normal text-sm px-4 py-2">
                ${accountBalance.toLocaleString()}
              </Badge>
            </div>
          </div>
        </div>
      </nav>
    </div>
  );
};