import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, BarChart3 } from 'lucide-react';

interface HeroProfileProps {
  name: string;
  title: string;
  symbol: string;
  image: string;
  price: number;
  marketCap: string;
  volume: string;
  change: number;
  about: string;
}

export const HeroProfile = ({ 
  name, 
  title, 
  symbol, 
  image, 
  price, 
  marketCap, 
  volume, 
  change, 
  about 
}: HeroProfileProps) => {
  const isPositive = change >= 0;
  
  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 min-h-screen">
      <div className="relative h-64 bg-gradient-to-r from-blue-900 to-purple-900 overflow-hidden">
        <div className="absolute inset-0 bg-black/30" />
        <div className="relative z-10 flex items-end h-full p-8">
          <div className="flex items-center space-x-6">
            <img 
              src={image} 
              alt={name} 
              className="w-24 h-24 rounded-full border-4 border-white object-cover"
            />
            <div>
              <h1 className="text-white text-4xl font-bold">{name}</h1>
              <p className="text-gray-300 text-lg">{title}</p>
              <Badge className="mt-2 bg-blue-600">{symbol}</Badge>
            </div>
          </div>
        </div>
      </div>
      
      <div className="px-8 py-6">
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800">
            <TabsTrigger value="overview" className="flex items-center space-x-2">
              <BarChart3 className="w-4 h-4" />
              <span>Overview</span>
            </TabsTrigger>
            <TabsTrigger value="works">Works</TabsTrigger>
            <TabsTrigger value="stats">Stats</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-6">
                    <h2 className="text-white text-xl font-bold mb-4">About</h2>
                    <p className="text-gray-300 leading-relaxed">{about}</p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="space-y-6">
                <Card className="bg-slate-800 border-slate-700">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-white font-bold">Market Data</h3>
                      <TrendingUp className={`w-5 h-5 ${isPositive ? 'text-green-400' : 'text-red-400'}`} />
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-400">Price</span>
                        <span className="text-white font-bold">CC {price.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">Market Cap</span>
                        <span className="text-white">{marketCap}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-400">24h Volume</span>
                        <span className="text-white">{volume}</span>
                      </div>
                    </div>
                    
                    <div className="flex space-x-2 mt-6">
                      <Button className="flex-1 bg-green-600 hover:bg-green-700">Buy</Button>
                      <Button variant="outline" className="flex-1 border-red-500 text-red-400 hover:bg-red-500 hover:text-white">
                        Sell
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};