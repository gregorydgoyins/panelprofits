import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface TemplateCardProps {
  name: string;
  symbol: string;
  price: number;
  change: number;
  image: string;
  marketCap: string;
  volume: string;
  className?: string;
}

export const TemplateCard = ({ 
  name, 
  symbol, 
  price, 
  change, 
  image, 
  marketCap, 
  volume,
  className = ""
}: TemplateCardProps) => {
  const isPositive = change >= 0;
  
  return (
    <Card className={`bg-gradient-to-br from-slate-900 to-slate-800 border-slate-700 hover:border-blue-500 transition-all duration-300 group ${className}`}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <img src={image} alt={name} className="w-12 h-12 rounded-full object-cover" />
            <div>
              <h3 className="text-white font-bold text-lg">{name}</h3>
              <Badge variant="secondary" className="text-xs">{symbol}</Badge>
            </div>
          </div>
          {isPositive ? (
            <TrendingUp className="text-green-400 w-5 h-5" />
          ) : (
            <TrendingDown className="text-red-400 w-5 h-5" />
          )}
        </div>
        
        <div className="space-y-2 mb-4">
          <div className="flex justify-between">
            <span className="text-gray-400">Price</span>
            <span className="text-white font-bold">${price.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">24h Change</span>
            <span className={`font-bold ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
              {isPositive ? '+' : ''}{change.toFixed(2)}%
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Market Cap</span>
            <span className="text-white">{marketCap}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-400">Volume</span>
            <span className="text-white">{volume}</span>
          </div>
        </div>
        
        <div className="flex space-x-2">
          <Button className="flex-1 bg-green-600 hover:bg-green-700">Buy</Button>
          <Button variant="outline" className="flex-1 border-red-500 text-red-400 hover:bg-red-500 hover:text-white">
            Sell
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};