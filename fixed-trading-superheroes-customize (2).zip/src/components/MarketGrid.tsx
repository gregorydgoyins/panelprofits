import { HeroCard } from './HeroCard';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, DollarSign, Users } from 'lucide-react';

const mockHeroes = [
  {
    name: 'Spider-Man',
    symbol: 'SPDR',
    price: 2525.00,
    change: 5.2,
    image: 'https://d64gsuwffb70l.cloudfront.net/681ec88e3e35c848fa9258d7_1748713525384_5ad80b65.jpg',
    marketCap: 'CC 125.0M',
    volume: 'CC 850.0K'
  },
  {
    name: 'Iron Man',
    symbol: 'IRON',
    price: 3200.00,
    change: -2.1,
    image: 'https://d64gsuwffb70l.cloudfront.net/681ec88e3e35c848fa9258d7_1748713537753_87509a7c.jpg',
    marketCap: 'CC 180.5M',
    volume: 'CC 1.2M'
  },
  {
    name: 'Wonder Woman',
    symbol: 'WNDR',
    price: 2800.50,
    change: 3.7,
    image: 'https://d64gsuwffb70l.cloudfront.net/681ec88e3e35c848fa9258d7_1748713538729_c447070b.jpg',
    marketCap: 'CC 145.2M',
    volume: 'CC 920.0K'
  },
  {
    name: 'Batman',
    symbol: 'BTMN',
    price: 4100.75,
    change: 1.8,
    image: 'https://d64gsuwffb70l.cloudfront.net/681ec88e3e35c848fa9258d7_1748713539694_105595c8.jpg',
    marketCap: 'CC 220.8M',
    volume: 'CC 1.5M'
  }
];

export const MarketGrid = () => {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Total Market Cap</p>
                <p className="text-white text-2xl font-bold">CC 2.1B</p>
              </div>
              <DollarSign className="text-green-400 w-8 h-8" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">24h Volume</p>
                <p className="text-white text-2xl font-bold">CC 45.2M</p>
              </div>
              <TrendingUp className="text-blue-400 w-8 h-8" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-slate-800 border-slate-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-400 text-sm">Active Traders</p>
                <p className="text-white text-2xl font-bold">12,847</p>
              </div>
              <Users className="text-purple-400 w-8 h-8" />
            </div>
          </CardContent>
        </Card>
      </div>
      
      <div>
        <h2 className="text-white text-2xl font-bold mb-6">Featured Heroes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {mockHeroes.map((hero, index) => (
            <HeroCard key={index} {...hero} />
          ))}
        </div>
      </div>
    </div>
  );
};