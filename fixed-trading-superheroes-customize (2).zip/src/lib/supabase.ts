import { createClient } from '@supabase/supabase-js';


// Initialize Supabase client
// Using direct values from project configuration
const supabaseUrl = 'https://bmubczmvwstvslhcgplr.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtdWJjem12d3N0dnNsaGNncGxyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDg3MTUwNTYsImV4cCI6MjA2NDI5MTA1Nn0.v83NKpgvFAMfyuJHk6K-Lo8MPlOSsn-9VNRobOWcy4E';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };