import { Zap, Shield, Star, Flame, Eye, Wind, Brain, Droplets, Mountain, Leaf, Sun, Moon, Heart, Diamond, Sword, Target, Hammer, Crown, Feather, Snowflake } from 'lucide-react';

export interface SuperHero {
  name: string;
  power: string;
  icon: any;
  gradient: string;
  image: string;
  universe?: string;
  powerLevel: 'Alpha' | 'Beta' | 'Gamma' | 'Omega';
}

export const superheroes: SuperHero[] = [
  { 
    name: "SUPERMAN", 
    power: "Invulnerability & Flight", 
    icon: Star, 
    gradient: "from-blue-400 via-red-500 to-yellow-600", 
    image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop", 
    universe: "DC", 
    powerLevel: "Omega" 
  },
  { 
    name: "BATMAN", 
    power: "Detective Skills & Gadgets", 
    icon: Moon, 
    gradient: "from-gray-800 via-slate-700 to-black", 
    image: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800&h=600&fit=crop", 
    universe: "DC", 
    powerLevel: "Beta" 
  },
  { 
    name: "WONDER WOMAN", 
    power: "Amazon Strength & Lasso", 
    icon: Crown, 
    gradient: "from-red-400 via-gold-500 to-blue-600", 
    image: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800&h=600&fit=crop", 
    universe: "DC", 
    powerLevel: "Alpha" 
  },
  { 
    name: "THE FLASH", 
    power: "Super Speed", 
    icon: Zap, 
    gradient: "from-red-400 via-yellow-500 to-orange-600", 
    image: "https://images.unsplash.com/photo-1525920980995-804834e4ab9c?w=800&h=600&fit=crop", 
    universe: "DC", 
    powerLevel: "Omega" 
  },
  { 
    name: "GREEN LANTERN", 
    power: "Will-Powered Constructs", 
    icon: Diamond, 
    gradient: "from-green-400 via-emerald-500 to-teal-600", 
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop", 
    universe: "DC", 
    powerLevel: "Alpha" 
  }
];