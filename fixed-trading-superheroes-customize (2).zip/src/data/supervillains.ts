import { Skull, Flame, Brain, Zap, Crown, Sword, Ghost, Mountain, Eye, Wind, Snowflake, Target, Magnet, Clock, Diamond, Anchor, Rocket, Sparkles, Shield, Star, Gem, Droplets, Moon, Heart, Hammer } from 'lucide-react';

export interface SuperVillain {
  name: string;
  power: string;
  icon: any;
  gradient: string;
  image: string;
  universe?: string;
  powerLevel: 'Alpha' | 'Beta' | 'Gamma' | 'Delta' | 'Epsilon' | 'Zeta' | 'Eta' | 'Theta' | 'Iota' | 'Kappa' | 'Lambda' | 'Mu' | 'Nu' | 'Xi' | 'Omicron' | 'Pi' | 'Rho' | 'Sigma' | 'Tau' | 'Upsilon' | 'Phi' | 'Chi' | 'Psi' | 'Omega';
  nemesisOf: string;
}

export const supervillains: SuperVillain[] = [
  // DC Villains
  { name: "LEX LUTHOR", power: "Genius Intellect & Technology", icon: Brain, gradient: "from-green-600 via-purple-700 to-black", image: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Beta", nemesisOf: "SUPERMAN" },
  { name: "JOKER", power: "Chaos & Insanity", icon: Skull, gradient: "from-purple-600 via-green-700 to-white", image: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Gamma", nemesisOf: "BATMAN" },
  { name: "CHEETAH", power: "Feline Speed & Claws", icon: Sword, gradient: "from-orange-600 via-brown-700 to-black", image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Beta", nemesisOf: "WONDER WOMAN" },
  { name: "REVERSE FLASH", power: "Negative Speed Force", icon: Zap, gradient: "from-yellow-600 via-red-700 to-black", image: "https://images.unsplash.com/photo-1525920980995-804834e4ab9c?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Omega", nemesisOf: "THE FLASH" },
  { name: "SINESTRO", power: "Fear-Powered Ring", icon: Gem, gradient: "from-yellow-600 via-orange-700 to-red-800", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Alpha", nemesisOf: "GREEN LANTERN" },
  { name: "BLACK MANTA", power: "Underwater Tech & Strength", icon: Droplets, gradient: "from-black via-red-700 to-blue-800", image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Beta", nemesisOf: "AQUAMAN" },
  { name: "BRAINIAC", power: "12th Level Intellect", icon: Brain, gradient: "from-green-600 via-purple-700 to-pink-800", image: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Omega", nemesisOf: "SUPERMAN" },
  { name: "DOOMSDAY", power: "Adaptive Evolution", icon: Mountain, gradient: "from-gray-600 via-black to-red-800", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Omega", nemesisOf: "SUPERMAN" },
  { name: "DARKSEID", power: "Omega Beams & Tyranny", icon: Eye, gradient: "from-gray-600 via-blue-700 to-red-800", image: "https://images.unsplash.com/photo-1518837695005-2083093ee35b?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Omega", nemesisOf: "SUPERMAN" },
  { name: "DEATHSTROKE", power: "Enhanced Abilities & Tactics", icon: Sword, gradient: "from-orange-600 via-black to-blue-800", image: "https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=800&h=600&fit=crop", universe: "DC", powerLevel: "Beta", nemesisOf: "BATMAN" }