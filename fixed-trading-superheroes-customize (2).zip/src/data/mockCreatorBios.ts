// Mock data for testing purposes only
// This allows us to create 100 unique creator bios with 1:1 relationship
// between creator ticker entries and detailed bio pages for testing navigation

export interface CreatorBio {
  id: number;
  name: string;
  work: string;
  value: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  slug: string;
  fullBio: string;
  majorWorks: string[];
  keyIssues: string[];
  firstAppearances: string[];
  influences: string[];
  relatedNews: string[];
  careerHighlights: string[];
  publishingHistory: string;
}

// Generate 100 unique creator bios for testing
export const generateCreatorBios = (): CreatorBio[] => {
  const bios: CreatorBio[] = [];
  
  const baseCreators = ['Stan Lee', 'Jack Kirby', 'Bob Kane', 'Jerry Siegel', 'Steve Ditko'];
  const works = ['Amazing Spider-Man', 'Batman Chronicles', 'X-Men Legacy', 'Superman Origins', 'Fantastic Four'];
  
  for (let i = 1; i <= 100; i++) {
    const creator = baseCreators[(i - 1) % baseCreators.length];
    const work = works[(i - 1) % works.length];
    const value = (Math.random() * 500 + 50).toFixed(2);
    const change = (Math.random() * 50 - 25).toFixed(2);
    
    bios.push({
      id: i,
      name: `${creator} (Bio ${i})`,
      work: `${work} Portfolio - Version ${i}`,
      value: `$${value}`,
      sentiment: parseFloat(change) > 0 ? 'positive' : parseFloat(change) < 0 ? 'negative' : 'neutral',
      slug: `creator-${i}`,
      fullBio: `This is the comprehensive biography for ${creator} - Version ${i}. This bio represents testing entry ${i} of 100 unique creator profiles. Each bio contains distinct information to test the 1:1 relationship between ticker entries and detailed pages.\n\nBio ${i} includes unique career details, publishing history, and creative contributions specific to this version of the creator's profile.`,
      majorWorks: [
        `${work} #${i}`,
        `Special Edition ${i}`,
        `Annual Collection ${i}`
      ],
      keyIssues: [
        `First Appearance: Issue #${i}`,
        `Milestone Issue #${i * 10}`,
        `Anniversary Special ${i}`
      ],
      firstAppearances: [
        `Character Debut ${i}`,
        `Series Launch ${i}`,
        `Universe Introduction ${i}`
      ],
      influences: [
        `Creative Influence ${i}`,
        `Industry Impact ${i}`,
        `Cultural Legacy ${i}`
      ],
      relatedNews: [`story-${i}`, `story-${((i % 50) + 1)}`],
      careerHighlights: [
        `Award Recognition ${i}`,
        `Industry Milestone ${i}`,
        `Creative Achievement ${i}`
      ],
      publishingHistory: `Publishing career spanning ${20 + (i % 30)} years with ${50 + i} major publications. Bio version ${i} represents unique career trajectory and achievements.`
    });
  }
  
  return bios;
};

export const mockCreatorBios = generateCreatorBios();