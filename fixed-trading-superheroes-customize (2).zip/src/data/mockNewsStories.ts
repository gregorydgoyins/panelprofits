// Mock data for testing purposes only
// This allows us to create 100 unique news stories with 1:1 relationship
// between ticker entries and detailed story pages for testing navigation

export interface NewsStory {
  id: number;
  headline: string;
  price: string;
  sentiment: 'positive' | 'negative' | 'neutral';
  slug: string;
  fullContent: string;
  stockMovement: {
    currentPrice: number;
    change: number;
    volume: string;
  };
  relatedCreators: string[];
  keyIssues: string[];
  publishDate: string;
}

// Generate 100 unique news stories for testing
export const generateNewsStories = (): NewsStory[] => {
  const stories: NewsStory[] = [];
  
  const baseHeadline = "Spider-Man Stock Soars After New Deal";
  const heroes = ['Spider-Man', 'Batman', 'Iron Man', 'Wonder Woman', 'Superman', 'Flash'];
  const events = ['New Deal', 'Movie Release', 'Comic Launch', 'Merger News', 'Tech Breakthrough'];
  
  for (let i = 1; i <= 100; i++) {
    const hero = heroes[(i - 1) % heroes.length];
    const event = events[(i - 1) % events.length];
    const price = (Math.random() * 100 + 10).toFixed(2);
    const change = (Math.random() * 20 - 10).toFixed(2);
    
    stories.push({
      id: i,
      headline: `${hero} Stock ${i > 50 ? 'Surges' : 'Soars'} After ${event} - Update ${i}`,
      price: `$${price}`,
      sentiment: parseFloat(change) > 0 ? 'positive' : parseFloat(change) < 0 ? 'negative' : 'neutral',
      slug: `story-${i}`,
      fullContent: `This is the detailed content for story update ${i}. The ${hero} property has seen significant market movement following ${event.toLowerCase()}. This represents update number ${i} in our comprehensive testing system where each story has unique content and relationships.\n\nKey developments include market analysis, stakeholder reactions, and future projections specific to update ${i}.`,
      stockMovement: {
        currentPrice: parseFloat(price),
        change: parseFloat(change),
        volume: `${(Math.random() * 1000 + 100).toFixed(0)}K`
      },
      relatedCreators: [`creator-${((i - 1) % 20) + 1}`],
      keyIssues: [`Issue #${i}`, `Special Edition ${i}`],
      publishDate: new Date(Date.now() - (i * 24 * 60 * 60 * 1000)).toISOString().split('T')[0]
    });
  }
  
  return stories;
};

export const mockNewsStories = generateNewsStories();